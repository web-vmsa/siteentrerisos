<?php

interface FilterComponentType
{
    const CONDITIONAL_GROUP = 'conditional_group';
    const GROUP = 'group';
    const CONDITION = 'condition';
}
